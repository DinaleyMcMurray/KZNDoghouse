package vcmsa.projects.thedoghouse_prototype

import android.app.Application
import com.google.firebase.FirebaseApp

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize Firebase once for the entire app
        FirebaseApp.initializeApp(this)
    }
}
